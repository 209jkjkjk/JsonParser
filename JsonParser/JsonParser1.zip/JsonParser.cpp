﻿#pragma once
#include <iostream>
#include <fstream>
#include <sstream> 
using namespace std;
#include "JsonParser.h"



ifstream JsonParser::loadFile(const string& filepath) {
    // 文件读取
    ifstream ifs(filepath, ios::in);
    // 判断是否成功开启
    if (!ifs.is_open()) {
        throw new runtime_error("文件打开失败");
    }
    return ifs;
}

string JsonParser::formatToString(ifstream& ifs) {
    // 判断文件大小，以为优化做判断
    ifs.seekg(0, std::ios::end);
    unsigned len = ifs.tellg();
    ifs.seekg(0, std::ios::beg);
    cout << "文件长度=" << len << endl;

    // 读取文件到字符串
    stringstream buffer;
    buffer << ifs.rdbuf();
    string s(buffer.str());

    // 去除回车以及换行
    for (auto it = s.begin(); it != s.end(); it++) {
        if (*it == ' ' || *it == '\n' || *it == '\t') {
            s.erase(it);
            it--;       // 保持迭代器指向正确
        }
    }

    return s;
}

void JsonParser::parse(const std::string s) {
    // 初始化根节点
    root = new JsonParser::JsonNode("root");
    // 初始化string迭代器
    auto it = s.begin();

    // 确保json格式合法性：①花括号开头
    if (*it++ != '{') throw runtime_error("json格式错误");

    // 提取属性名
    string attributeName = _extractAttributeName(it);
    // 判断数据类型类型
    auto type = _judg1eType(it);
    // 初始化子节点
    root->children.insert(make_pair(attributeName, new JsonParser::JsonNode(attributeName, root, type)));
    
    string value;
    // 分类处理
    switch (type)
    {
    case JsonParser::JsonNode::object:
        break;
    case JsonParser::JsonNode::array:
        break;
    // 如果是非嵌套的数据
    case JsonParser::JsonNode::null:
    case JsonParser::JsonNode::string:
    case JsonParser::JsonNode::number:
    case JsonParser::JsonNode::boolean:
        value = _extractAttributeValue(it);
        break;
    default:
        break;
    }
    if (type != JsonParser::JsonNode::JsonNodeType::object && \
        type != JsonParser::JsonNode::JsonNodeType::array) {
        
    }
    // 如果是嵌套类型
    else {

    }
    

}

string JsonParser::_extractAttributeName(string::const_iterator& it) {
    // 确保json格式合法性：①双引号开头 ②属性名长度不为0
    if (*it++ != '"' || *it == '"') throw runtime_error("json格式错误");

    // 扫描计算属性名长度
    unsigned attributeNameLength = 0;
    do {
        ++attributeNameLength;
    } while (*(it + attributeNameLength) != '"');
    // 截取字符串得到属性名
    string name(it, it + attributeNameLength);
    cout << "得到属性名：" << name << endl;;
    // 移动迭代器至属性名后一个字符（理应为双引号)
    it += attributeNameLength;

    // 确保json格式合法性：①双引号结尾 ②后面有冒号
    if (*it++ != '"' || *it++ != ':') throw runtime_error("json格式错误");

    return name;
}

JsonParser::JsonNode::JsonNodeType JsonParser::_judg1eType(string::const_iterator& it) {
    if (*it == '"') return JsonParser::JsonNode::JsonNodeType::string;
    else if (*it == 'n') return JsonParser::JsonNode::JsonNodeType::null;
    else if (*it >= '0' && *it <= '9') return JsonParser::JsonNode::JsonNodeType::number;
    else if (*it == '{') return JsonParser::JsonNode::JsonNodeType::object;
    else if (*it == '[') return JsonParser::JsonNode::JsonNodeType::array;
    else if (*it == 'f' || *it == 't') return JsonParser::JsonNode::JsonNodeType::boolean;
    else throw runtime_error("非法json数据类型");
}

string JsonParser::_extractAttributeValue(string::const_iterator& it) {
    // 扫描计算属性值长度
    unsigned attributeValueLength = 0;
    do {
        ++attributeValueLength;
    } while (*(it + attributeValueLength) != ',' && *(it + attributeValueLength) != '}');
    // 截取字符串得到属性值
    string value(it, it + attributeValueLength);
    cout << "得到属性值：" << value << endl;

    return value;
}



int main()
{
    try {
    JsonParser jsp;
    auto c = jsp.loadFile("jsontest.json");
    auto d = jsp.formatToString(c);
    cout << d <<endl;
    jsp.parse(d);
    }
    catch (runtime_error e) {
        cout << "错误是：" << e.what();
    }
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
